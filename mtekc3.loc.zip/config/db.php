<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=mtek3',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
