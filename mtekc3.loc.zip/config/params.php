<?php

return [
    'adminEmail' => 'webdizain@bk.ru',
];
